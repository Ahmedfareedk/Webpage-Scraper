package com.example.httpurlconnection.util;

public interface Constants {
  String BASE_URL = "https://instabug.com/";
}
