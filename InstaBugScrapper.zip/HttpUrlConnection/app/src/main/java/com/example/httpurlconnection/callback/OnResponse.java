package com.example.httpurlconnection.callback;

import org.json.JSONObject;

import java.util.List;

public interface OnResponse {
    void onResponse(List<String> response);
}
